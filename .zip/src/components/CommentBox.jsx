import { useEffect, useState } from "react";
import { useAuth } from "../contexts/AuthContext";

export default function CommentBox({ meetingId }) {
  const { user } = useAuth();
  const [comment, setComment] = useState("");
  const [comments, setComments] = useState([]);

  useEffect(() => {
    const all = JSON.parse(localStorage.getItem("comments")) || [];
    const current = all.filter((c) => c.meetingId === meetingId);
    setComments(current);
  }, [meetingId]);

  const saveComments = (updated) => {
    const all = JSON.parse(localStorage.getItem("comments")) || [];
    const others = all.filter((c) => c.meetingId !== meetingId);
    localStorage.setItem("comments", JSON.stringify([...others, ...updated]));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!comment.trim()) return;
    const newComment = {
      id: Date.now(),
      text: comment,
      meetingId,
      author: user.name,
    };
    const updated = [...comments, newComment];
    setComments(updated);
    saveComments(updated);
    setComment("");
  };

  return (
    <div style={{ marginTop: "10px" }}>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={comment}
          placeholder="Оставить комментарий..."
          onChange={(e) => setComment(e.target.value)}
          style={{
            padding: "8px",
            width: "80%",
            border: "1px solid #aaa",
            borderRadius: "4px",
          }}
        />
        <button
          type="submit"
          style={{
            padding: "8px",
            marginLeft: "8px",
            background: "#28a745",
            color: "white",
            border: "none",
            borderRadius: "4px",
            cursor: "pointer",
          }}
        >
          ➤
        </button>
      </form>

      <ul style={{ marginTop: "10px", paddingLeft: "15px" }}>
        {comments.map((c) => (
          <li key={c.id}>
            <strong>{c.author}:</strong> {c.text}
          </li>
        ))}
      </ul>
    </div>
  );
}
