import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useTheme } from "../contexts/ThemeContext";
import { useLanguage } from "../contexts/LanguageContext";
import { useTranslation } from "react-i18next";
import "./Navbar.css";

export default function Navbar() {
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { toggleLanguage, lang } = useLanguage();
  const { t } = useTranslation();

  if (!user) return null;

  return (
    <nav className="navbar">
      <div className="navbar-left">
        <span className="navbar-logo">MeetingManager</span>
        <Link to="/dashboard">{t("home")}</Link>
        <Link to="/meetings">{t("meetings")}</Link>
        <Link to="/profile">{t("profile")}</Link>
        {user.role === "admin" && <Link to="/admin">{t("admin")}</Link>}
      </div>

      <div className="navbar-right">
        <button onClick={toggleTheme} className="theme-toggle">
          {theme === "light" ? "🌙" : "☀️"}
        </button>

        <button onClick={toggleLanguage} className="theme-toggle">
          {lang === "ru" ? "EN" : "RU"}
        </button>

        <div className="navbar-user">
          {user.avatar && (
            <img src={user.avatar} alt="avatar" className="navbar-avatar" />
          )}
          <span>{user.name}</span>
        </div>
      </div>
    </nav>
  );
}
