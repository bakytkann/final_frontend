import { useAuth } from "../contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import "../styles/Footer.css";

export default function LogoutFooter() {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const { t } = useTranslation();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <div className="logout-footer">
      <button onClick={handleLogout} className="logout-btn">
        {t("logout")}
      </button>
    </div>
  );
}
