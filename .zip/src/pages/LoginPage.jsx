import { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { useTranslation } from "react-i18next";
import "../styles/LoginPage.css";

export default function LoginPage() {
  const { login, register } = useAuth();
  const navigate = useNavigate();
  const [isRegister, setIsRegister] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const { t } = useTranslation();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (isRegister) {
      const success = register(form.name, form.email, form.password);
      if (!success) return toast.error(t("user_exists"));
      toast.success(t("register_success"));
      setIsRegister(false);
    } else {
      const success = login(form.email, form.password);
      if (!success) return toast.error(t("invalid_login"));
      toast.success(t("login_success"));
      navigate("/dashboard");
    }
  };

  return (
    <div className="auth-container">
      <h2>{isRegister ? t("register") : t("login")}</h2>
      <form onSubmit={handleSubmit}>
        {isRegister && (
          <input
            type="text"
            placeholder={t("name")}
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            required
          />
        )}
        <input
          type="email"
          placeholder="Email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          required
        />
        <input
          type="password"
          placeholder={t("password")}
          value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
          required
        />
        <button type="submit">
          {isRegister ? t("register") : t("login")}
        </button>
        <button
          type="button"
          className="switch-btn"
          onClick={() => setIsRegister(!isRegister)}
        >
          {isRegister ? t("already_have_account") : t("no_account")}
        </button>
      </form>
    </div>
  );
}
