import { useTranslation } from "react-i18next";

export default function NotFound() {
  const { t } = useTranslation();

  return (
    <h2 style={{ textAlign: "center", marginTop: "40px" }}>
      {t("not_found")}
    </h2>
  );
}
