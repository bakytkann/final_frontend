import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";

export default function AdminPage() {
  const [users, setUsers] = useState([]);
  const { t } = useTranslation();

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem("users")) || [];
    setUsers(stored);
  }, []);

  return (
    <div style={{ maxWidth: "600px", margin: "40px auto" }}>
      <h2>{t("admin_users")}</h2>
      <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "20px" }}>
        <thead>
          <tr>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>{t("name")}</th>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>Email</th>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>{t("role")}</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u, i) => (
            <tr key={i}>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>{u.name}</td>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>{u.email}</td>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>{u.role}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

