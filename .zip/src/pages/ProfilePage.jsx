import { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { toast } from "react-toastify";
import { useTranslation } from "react-i18next";
import "../styles/ProfilePage.css";

export default function ProfilePage() {
  const { user, updateProfile } = useAuth();
  const { t } = useTranslation();
  const [name, setName] = useState(user?.name || "");
  const [email, setEmail] = useState(user?.email || "");
  const [avatar, setAvatar] = useState(user?.avatar || "");

  const handleUpdate = (e) => {
    e.preventDefault();
    updateProfile({ name, email, avatar });
    toast.success(t("profile_updated"));
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result.toString();
      setAvatar(base64);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="profile-container">
      <h2>{t("profile")}</h2>
      <form onSubmit={handleUpdate}>
        <div className="avatar-box">
          {avatar ? (
            <img src={avatar} alt="avatar" className="avatar" />
          ) : (
            <div className="avatar-placeholder">{t("no_avatar")}</div>
          )}
          <input type="file" accept="image/*" onChange={handleAvatarChange} />
        </div>

        <input
          type="text"
          placeholder={t("name")}
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />

        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <button type="submit">{t("save_changes")}</button>
      </form>
    </div>
  );
}

