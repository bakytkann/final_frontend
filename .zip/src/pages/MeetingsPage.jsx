import { useEffect, useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { toast } from "react-toastify";
import { useTranslation } from "react-i18next";
import CommentBox from "../components/CommentBox";
import "../styles/components.css";

export default function MeetingsPage() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [meetings, setMeetings] = useState([]);
  const [form, setForm] = useState({ title: "", description: "", date: "" });

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("meetings")) || [];
    const userMeetings = saved.filter((m) => m.userEmail === user.email);
    setMeetings(userMeetings);
  }, [user.email]);

  const saveMeetings = (data) => {
    const all = JSON.parse(localStorage.getItem("meetings")) || [];
    const filtered = all.filter((m) => m.userEmail !== user.email);
    localStorage.setItem("meetings", JSON.stringify([...filtered, ...data]));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newMeeting = {
      id: Date.now(),
      title: form.title,
      description: form.description,
      date: form.date,
      userEmail: user.email,
      userName: user.name,
    };
    const updated = [...meetings, newMeeting];
    setMeetings(updated);
    saveMeetings(updated);
    setForm({ title: "", description: "", date: "" });
    toast.success(t("meeting_added"));
  };

  const handleDelete = (id) => {
    const updated = meetings.filter((m) => m.id !== id);
    setMeetings(updated);
    saveMeetings(updated);
    toast.info(t("meeting_deleted"));
  };

  return (
    <div className="meetings-container">
      <h2>{t("my_meetings")}</h2>
      <form className="meeting-form" onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder={t("meeting_title")}
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          required
        />
        <input
          type="text"
          placeholder={t("meeting_description")}
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
        />
        <input
          type="datetime-local"
          value={form.date}
          onChange={(e) => setForm({ ...form, date: e.target.value })}
          required
        />
        <button type="submit">{t("add_meeting")}</button>
      </form>

      <ul className="meeting-list">
        {meetings.length === 0 && <p>{t("no_meetings")}</p>}
        {meetings.map((meeting) => (
          <li key={meeting.id} className="meeting-item">
            <div>
              <strong>{meeting.title}</strong>
              <p>{meeting.description}</p>
              <small>{new Date(meeting.date).toLocaleString()}</small>
              <CommentBox meetingId={meeting.id} />
            </div>
            <button onClick={() => handleDelete(meeting.id)}>{t("delete")}</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
