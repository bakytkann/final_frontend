import { useEffect, useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useTranslation } from "react-i18next";
import CommentBox from "../components/CommentBox";

export default function DashboardPage() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [meetings, setMeetings] = useState([]);

  useEffect(() => {
    const all = JSON.parse(localStorage.getItem("meetings")) || [];
    const sorted = [...all].sort((a, b) => new Date(b.date) - new Date(a.date));
    setMeetings(sorted);
  }, []);

  return (
    <div style={{ maxWidth: "700px", margin: "40px auto", padding: "10px" }}>
      <h1 style={{ textAlign: "center" }}>
        {t("welcome")}, {user?.name}!
      </h1>
      <p style={{ textAlign: "center", marginBottom: "30px" }}>
        {t("my_meetings")}
      </p>

      {meetings.length === 0 && <p>{t("no_meetings")}</p>}

      <ul style={{ listStyle: "none", padding: 0 }}>
        {meetings.map((meeting) => (
          <li key={meeting.id} className="meeting-item">
            <div>
              <strong>{meeting.title}</strong>
              <p>{meeting.description}</p>
              <small>
                {new Date(meeting.date).toLocaleString()}
                {meeting.userName && <> • <strong>{meeting.userName}</strong></>}
              </small>
              <CommentBox meetingId={meeting.id} />
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
